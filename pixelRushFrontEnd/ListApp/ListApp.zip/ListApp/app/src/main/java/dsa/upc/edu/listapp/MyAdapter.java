package dsa.upc.edu.listapp;

import java.util.ArrayList;
import java.util.List;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import dsa.upc.edu.listapp.github.Contributor;
//Adaptador - no hace falta saber hacerlo de 0
public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {     //ViewHolder: mantiene las vistas, tiene unas variables que apuntan a las diferentes vistas del sistema.
    private List<Contributor> values;       //Lista de contributos donde se almacenan

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public class ViewHolder extends RecyclerView.ViewHolder {       //contiene lo que teniamos en el row_layout
        // each data item is just a string in this case
        public TextView txtHeader;
        public TextView txtFooter;
        public ImageView icon;
        public View layout;

        //Constructor
        public ViewHolder(View v) {
            super(v);
            layout = v;
            txtHeader = (TextView) v.findViewById(R.id.firstLine);
            txtFooter = (TextView) v.findViewById(R.id.secondLine);
            icon = (ImageView) v.findViewById(R.id.icon);
        }

        //YA tenemos generado el viewholder
    }
//funciones para hacer algo. Operaciones para que la vista se de cuenta de que ha cambiado
    public void setData(List<Contributor> myDataset) {
        values = myDataset;
        notifyDataSetChanged();     //Notificia de que la vista ha cambiado
    }

    public void add(int position, Contributor item) {
        values.add(position, item);
        notifyItemInserted(position);       //Notificamos qaue hemos modificado un cierto trozo de la pantalla. Con esto hace que android no tenga que volver a imprimir cosas que ya estan imprimidas.
    }

    public void remove(int position) {
        values.remove(position);
        notifyItemRemoved(position);
    }

    public MyAdapter() {
        values = new ArrayList<>();
    }       //Creamos una lista vacia

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyAdapter(List<Contributor> myDataset) {values = myDataset;}     //creamos una lista de contribuidores

    // Create new views (invoked by the layout manager) Siempre es igual
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                   int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(
                parent.getContext());
        View v =
                inflater.inflate(R.layout.row_layout, parent, false);
        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager). Cambia dependiendo de lo que queramos hacer
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        Contributor c = values.get(position); //recuperamos el contributor
        final String name = c.login; //Cogemos valor del login
        holder.txtHeader.setText(name); //Estamos asignando el name
        holder.txtHeader.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                remove(holder.getAdapterPosition());
            }//Cuando clickes el elemento se va a borrar
        });

        holder.txtFooter.setText("Contributions: " + c.contributions);

        GlideApp.with(holder.icon.getContext())
                .load(c.avatar_url)
                .into(holder.icon);
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return values.size();
    }   //Obtener el total de elementos

}